public abstract class DividaAbstrata{
  public abstract float getvalor();
}
