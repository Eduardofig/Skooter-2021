public class Divida extends DividaAbstrata{
  protected float valor;

  public Divida(float valor){
    this.valor = valor;
  }

  public float getvalor(){
    return this.valor;
  }
}
