public interface MeusVetoresFunction {
    public abstract int[] ExecutaFuncoes(MeusVetores mv);
}
