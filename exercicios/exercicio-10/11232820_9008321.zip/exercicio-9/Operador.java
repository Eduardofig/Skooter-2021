public interface Operador {
    public double raizQuadrada(double num); 

    public double quadrado(double num);
}
